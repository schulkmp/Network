namespace Network.Raknet.Handler.Codec.Raknet.Common;

public class UnconnectedPongEncoder
{
    
}