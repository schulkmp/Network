namespace Network.Raknet.Channel.Raknet.Config;

public class DefaultRakServerThrottle
{
    
}